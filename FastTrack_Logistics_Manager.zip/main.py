import tkinter as tk
import json
import requests
from tkinter import ttk

class TodoListApp:
    def __init__(self, root, data=None):
        self.root = root
        self.data = data or []
        self.update_display()

    def update_display(self):
        self.listbox.delete(0, tk.END)
        for item in self.data:
            self.listbox.insert(tk.END, item['text'])

    def add_item(self, text):
        self.data.append({'text': text, 'completed': False})
        self.update_display()

    def delete_item(self, index):
        try:
            del self.data[index]
            self.update_display()
        except IndexError:
            print("Invalid index")

    def get_item(self, index):
        try:
            return self.data[index]['text']
        except KeyError:
            return None

class Root:
    def __init__(self, bg='#121212'):
        self.root = tk.Tk()
        self.root.configure(bg=bg)
        self.root.lift()
        self.root.mainloop()

if __name__ == '__main__':
    # Sample data (replace with your actual data source)
    data = [
        {'text': 'Buy groceries', 'completed': False},
        {'text': 'Pay bills', 'completed': True},
        {'text': 'Walk the dog', 'completed': False}
    ]
    
    # Load data from JSON
    try:
        with open('data.json', 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print("data.json not found. Starting with an empty list.")
        data = []
    except json.JSONDecodeError:
        print("Error decoding data.json. Starting with an empty list.")
        data = []

    root = Root()
    todo_list = TodoListApp(root)
    
    # Example usage:
    todo_list.add_item('Buy milk')
    todo_list.add_item('Pay rent')
    
    # Display the listbox
    todo_list.listbox.pack()