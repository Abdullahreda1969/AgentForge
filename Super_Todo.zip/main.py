import tkinter as tk
import json
import os

def load_tasks():
    tasks = []
    for filename in os.listdir('.'):
        if filename == 'tasks.json':
            with open(filename, 'r') as f:
                tasks = json.load(f)
    with open('tasks.json', 'w') as f:
        json.dump(tasks, f)
    root = tk.Tk()
    root.title('Super Todo')
    entry = tk.Entry(root, width=40)
    entry.insert(0, 'Enter task')
    button = tk.Button(root, text='Add', command=load_tasks)
    button.pack()
    listbox = tk.Listbox(root, width=50)
    listbox.insert(0, 'Task 1')
    listbox.insert(1, 'Task 2')
    listbox.insert(2, 'Task 3')
    root.mainloop()

def add_item(entry):
    task = entry.get()
    tasks.append(task)
    entry.delete(0, tk.END)
    listbox.insert(0, task)

def update_listbox(tasks):
    listbox.delete(0, tk.END)
    for task in tasks:
        listbox.insert(0, task)

if __name__ == "__main__":
    load_tasks()
    add_item(entry)
    update_listbox(tasks)